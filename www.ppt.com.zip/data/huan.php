<?php
return array (
  'status' => 
  array (
    0 => '<font color=#ff3300>兑换审核中...</font>',
    1 => '<font color=#009900>兑换成功</font>',
    2 => '<font color=#333333>兑换失败</font>',
  ),
  'fangshi' => 
  array (
    1 => TBMONEY.'兑换',
    2 => '积分兑换',
  ),
)
?>