<?php
 return array (
  array (
    'mod' => 'tao',
    'act' => 'coupon',
    'tag' => 'tao_coupon',
  ),
  array (
    'mod' => 'mall',
    'act' => 'goods',
    'tag' => 'bijia',
  ),
);
?>