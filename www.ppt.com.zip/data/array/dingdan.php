<?php
 return array (
  0 => 
  array (
    'item_title' => '2012夏季女装新款欧美外贸小清新季节芥末黄色连衣裙',
    'num_iid' => '16726324552',
    'jifenbao' => '11.25',
    'commission_rate' => 5,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1YxfeXeViXXaBz8w0_035947.jpg',
  ),
  1 => 
  array (
    'item_title' => '2012夏季男士英伦休闲格子短裤 男式韩版修身短裤五分裤中裤5分裤',
    'num_iid' => '9871306695',
    'jifenbao' => '5.48',
    'commission_rate' => 8,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1ekHXXeJlXXaEOd39_102835.jpg',
  ),
  2 => 
  array (
    'item_title' => '2012新款夏装走秀欧美大牌原单柳岩刘诗诗同款印花背心裙连衣裙女',
    'num_iid' => '14282001293',
    'jifenbao' => '7.97',
    'commission_rate' => 4,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1TVrgXghsXXcGvSza_122259.jpg',
  ),
  3 => 
  array (
    'item_title' => '2012新款时尚蓝色包臀牛仔裙短裙 女款夏季韩版包裙半身裙 潮 03S',
    'num_iid' => '16925192118',
    'jifenbao' => '5.85',
    'commission_rate' => 9,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1BNfxXlpbXXXZoaw0_034246.jpg',
  ),
  4 => 
  array (
    'item_title' => '2012新款欧美外贸皇室宫廷超豪华抹胸绑带蕾丝鱼尾高档定做婚纱',
    'num_iid' => '17329956721',
    'jifenbao' => '21.40',
    'commission_rate' => 4,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1hOPjXjprXXXZFrLa_120307.jpg',
  ),
  5 => 
  array (
    'item_title' => '2012春装新款女装韩版连衣裙大码连衣裙娃娃款荷叶边宽松连衣裙女',
    'num_iid' => '14362109762',
    'jifenbao' => '6.25',
    'commission_rate' => 8,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1ZX18XghdXXXmEUQ9_075120.jpg',
  ),
  6 => 
  array (
    'item_title' => '365sleep 全方位 蝶形慢回弹 颈椎枕 保健护颈枕 记忆枕 枕头',
    'num_iid' => '10697448167',
    'jifenbao' => '13.16',
    'commission_rate' => 9,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1GjHwXoXaXXa.p1LX_084737.jpg',
  ),
  7 => 
  array (
    'item_title' => 'CAVSER夏季时尚欧美风女式夹脚坡跟人字拖厚底凉拖鞋沙滩鞋 黑宽',
    'num_iid' => '13811625793',
    'jifenbao' => '5.10',
    'commission_rate' => 8,
    'name' => '******',
    'img' => 'http://img06.taobaocdn.com/bao/uploaded/i6/T1zzSXXgxsXXXLeHvb_093208.jpg',
  ),
  8 => 
  array (
    'item_title' => 'HTC 倾心S510B S710e  X315e ONE X t328d X515dM 手机壳 保护套',
    'num_iid' => '14694271064',
    'jifenbao' => '6.80',
    'commission_rate' => 10,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1HNbyXhViXXbquOUV_021158.jpg',
  ),
  9 => 
  array (
    'item_title' => 'JOSEN地中海风格波西米亚田园石膏吸顶灯具阳台过道灯饰K5044',
    'num_iid' => '8195560162',
    'jifenbao' => '9.18',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1eYh6XedkXXct4RQ3_051116.jpg',
  ),
  10 => 
  array (
    'item_title' => 'LAVER强效脱毛膏永久绝毛温和 防敏腋毛腿毛正品男女脱毛爽肤膏',
    'num_iid' => '3423563570',
    'jifenbao' => '9.63',
    'commission_rate' => 17,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1c1nPXnViXXXDNoUT_013354.jpg',
  ),
  11 => 
  array (
    'item_title' => 'Midea/美的 PF006-50G电热水瓶保温电热水壶电水壶5L正品包邮特价',
    'num_iid' => '9454489927',
    'jifenbao' => '5.21',
    'commission_rate' => 2,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T114TBXchnXXcP.HsY_025513.jpg',
  ),
  12 => 
  array (
    'item_title' => 'OECE正品/复古海派彼得潘领蕾丝小衫条纹修身长款连衣裙',
    'num_iid' => '17459100055',
    'jifenbao' => '5.55',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1cWSDXet1XXXT9Fs2_042710.jpg',
  ),
  13 => 
  array (
    'item_title' => 'PBA YangSang柔肤全效BB霜50g 裸妆遮瑕强隔离粉底保湿正品包邮',
    'num_iid' => '3691047764',
    'jifenbao' => '8.01',
    'commission_rate' => 12,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1zLYYXoldXXcONgTX_115318.jpg',
  ),
  14 => 
  array (
    'item_title' => 'SmartYou正品 男士钱包牛皮钱包潮 金砂商务 横竖款个性雕刻 包邮',
    'num_iid' => '9040394832',
    'jifenbao' => '9.48',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1ZTYtXfXrXXXtO3jX_114938.jpg',
  ),
  15 => 
  array (
    'item_title' => '[多米乐]现代简约台灯 田园花草台灯 铁艺台灯T7137',
    'num_iid' => '12671117063',
    'jifenbao' => '5.70',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T13w9RXcloXXb.HEMZ_034033.jpg',
  ),
  16 => 
  array (
    'item_title' => '[多米乐]现代简约台灯 田园花草台灯 铁艺台灯T7138',
    'num_iid' => '12828247453',
    'jifenbao' => '5.88',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1PReTXd0bXXX1Rr6X_084412.jpg',
  ),
  17 => 
  array (
    'item_title' => 'cherrykeke2012夏季新款大码长纱裙修身蓬蓬裙雪纺连衣裙长裙子',
    'num_iid' => '16242980072',
    'jifenbao' => '5.29',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T13mzlXgJrXXbZSygT_011924.jpg',
  ),
  18 => 
  array (
    'item_title' => 'vivi杂志款2012夏新款欧美复古网纱雪纺蕾丝绣花牛仔连衣裙L80112',
    'num_iid' => '15868268842',
    'jifenbao' => '5.94',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T1zVfwXeloXXX.zsU5_054941.jpg',
  ),
  19 => 
  array (
    'item_title' => '【华艺照明】现代简约 云彩石吸顶灯KX07 门厅灯阳台灯过道灯具',
    'num_iid' => '14465269595',
    'jifenbao' => '6.61',
    'commission_rate' => 10,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1F8nTXXFlXXcYn1U9_103239.jpg',
  ),
  20 => 
  array (
    'item_title' => '【浅爱】瑛S3406新款2012夏季甜美钉珠修身短袖牛仔连衣裙 短裙子',
    'num_iid' => '14815717807',
    'jifenbao' => '5.18',
    'commission_rate' => 8,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T11J2cXhheXXbyKkDa_092031.jpg',
  ),
  21 => 
  array (
    'item_title' => '【狂暑季】希捷 GoFlex 睿品 500G移动硬盘 USB3.0硬盘 全国联保',
    'num_iid' => '10031604356',
    'jifenbao' => '5.74',
    'commission_rate' => 1,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T148YvXcBXXXcmuYvb_093209.jpg',
  ),
  22 => 
  array (
    'item_title' => '【聚】瑞西屋正品 夏凉席三件套 特价双人仿藤席套件 可折叠席子',
    'num_iid' => '15013491125',
    'jifenbao' => '7.51',
    'commission_rate' => 10,
    'name' => '******',
    'img' => 'http://img08.taobaocdn.com/bao/uploaded/i8/T1Pj2PXipgXXatwr34_051905.jpg',
  ),
  23 => 
  array (
    'item_title' => '不参加卓欧2012新款碎花长裙子雪纺吊带连衣裙夏季沙滩裙F105002',
    'num_iid' => '10365359448',
    'jifenbao' => '14.67',
    'commission_rate' => 9,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1wFTrXi4tXXX3Sfg8_070349.jpg',
  ),
  24 => 
  array (
    'item_title' => '专柜代购哥弟阿玛施2012新款女士真丝棉短袖衬衫GA33210208467-3',
    'num_iid' => '16021232378',
    'jifenbao' => '9.30',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ctngXlJqXXbJrrA._111407.jpg',
  ),
  25 => 
  array (
    'item_title' => '专柜联保正品 Swatch手表 2012 新炫彩 原装 代购手表 男表 女表',
    'num_iid' => '9535513694',
    'jifenbao' => '9.25',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T1wPPqXmFoXXXtp3La_120933.jpg',
  ),
  26 => 
  array (
    'item_title' => '久拉拉七分裤女裤子 夏季新款哈伦裤打底显瘦休闲裤女小脚裤K641',
    'num_iid' => '17263008736',
    'jifenbao' => '5.41',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T1IDzvXoNXXXcsgicU_014842.jpg',
  ),
  27 => 
  array (
    'item_title' => '买一送2！ABS+pc拉杆箱万向轮亚光防刮旅行箱行李箱登机箱 包邮费',
    'num_iid' => '13325329073',
    'jifenbao' => '5.66',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1IE6yXmRoXXbT4vDX_114851.jpg',
  ),
  28 => 
  array (
    'item_title' => '包邮 内蒙古万利福 亚麻籽油初榨冷 三高便秘必备 正品食用油批发',
    'num_iid' => '3168814081',
    'jifenbao' => '28.66',
    'commission_rate' => 10,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T12NzFXmFiXXaIy2U0_035236.jpg',
  ),
  29 => 
  array (
    'item_title' => '千卓凉鞋2012新品凉鞋女鞋鱼嘴高跟女凉鞋拼色新款女凉鞋伊琳格瑞',
    'num_iid' => '14822930131',
    'jifenbao' => '8.41',
    'commission_rate' => 5,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1yufoXnRbXXXGo0Lb_123502.jpg',
  ),
  30 => 
  array (
    'item_title' => '千芳汇正品 强效瘦腿精油刮痧瘦腿 瘦身减肥精油 店主真人秀',
    'num_iid' => '8156444336',
    'jifenbao' => '10.62',
    'commission_rate' => 15,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1GSvYXlteXXXalpLa_120040.jpg',
  ),
  31 => 
  array (
    'item_title' => '品奥正品 神奇 双驱动手压 旋转 拖把 好神拖 墩布头 拖布桶包邮',
    'num_iid' => '16909980043',
    'jifenbao' => '5.30',
    'commission_rate' => 7,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T16jvbXkljXXXtYbo__105440.jpg',
  ),
  32 => 
  array (
    'item_title' => '四君子汤 益气健脾 脾胃虚弱者必备 一付3元 满20付包邮',
    'num_iid' => '3534195835',
    'jifenbao' => '5.80',
    'commission_rate' => 10,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1GQR8XfJhXXXXmjE8_100917.jpg',
  ),
  33 => 
  array (
    'item_title' => '夏装新款女裤 韩版宽松超仙飘逸雪纺休闲裙裤 高腰显瘦阔腿裤裤子',
    'num_iid' => '17331120583',
    'jifenbao' => '7.10',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T10wnlXjllXXXuAlDb_094804.jpg',
  ),
  34 => 
  array (
    'item_title' => '多米乐 韩式时尚田园吸顶灯客厅卧室花草灯书房花灯饰灯具MD8689',
    'num_iid' => '14779008744',
    'jifenbao' => '10.80',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T11gOHXfBeXXbJdU_b_095534.jpg',
  ),
  35 => 
  array (
    'item_title' => '威妮华欧美饰品 时尚项链 性感 夸张 长链 猎豹毛衣链 正品 礼物',
    'num_iid' => '12776629442',
    'jifenbao' => '27.02',
    'commission_rate' => 17,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T10mTUXj0cXXa0Wqg._111234.jpg',
  ),
  36 => 
  array (
    'item_title' => '左旋肉碱 减肥药胶囊纯中药减 淝 左旋肉减 正品 减肥减肚',
    'num_iid' => '4951801639',
    'jifenbao' => '30.38',
    'commission_rate' => 23,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T1OdYPXXRoXXXOIwET_011720.jpg',
  ),
  37 => 
  array (
    'item_title' => '店庆！法国进口红酒 梵帝雅干红葡萄酒 红酒礼盒装 包邮送礼品酒',
    'num_iid' => '12967635557',
    'jifenbao' => '11.71',
    'commission_rate' => 9,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1AYYpXjpuXXX46nQ8_102045.jpg',
  ),
  38 => 
  array (
    'item_title' => '情侣睡衣春秋夏长袖短袖仿真丝男士女士居家服女款丝绸家居服套装',
    'num_iid' => '14247781818',
    'jifenbao' => '13.20',
    'commission_rate' => 15,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1T8O4XbJgXXcoGYPa_120314.jpg',
  ),
  39 => 
  array (
    'item_title' => '想川阮青馨夏季男鞋透气鞋男士休闲鞋懒人鞋情侣鞋低帮鞋男75726',
    'num_iid' => '14684194749',
    'jifenbao' => '7.92',
    'commission_rate' => 8,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T17JzqXXReXXcVDNQ8_100700.jpg',
  ),
  40 => 
  array (
    'item_title' => '换肤堂秘制-专供某媒体内部用祛痘秘方，NN天根除10年痘!疤印毛孔',
    'num_iid' => '1496381556',
    'jifenbao' => '14.40',
    'commission_rate' => 5,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1CuVCXbpqXXb1Opc__104853.jpg',
  ),
  41 => 
  array (
    'item_title' => '推荐！all saints 中长款 大翻领 加棉里衬 双排扣呢子外套F044',
    'num_iid' => '13810903059',
    'jifenbao' => '6.31',
    'commission_rate' => 4,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T1C1GMXk0sXXb0D8Z2_044901.jpg',
  ),
  42 => 
  array (
    'item_title' => '播 与奶茶对话 韩版宽松糖果色薄款七分袖针织开衫空调防晒衫女',
    'num_iid' => '17018488572',
    'jifenbao' => '10.01',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T142HqXXFwXXa1th3Z_032558.jpg',
  ),
  43 => 
  array (
    'item_title' => '播专柜正品 自由风 新款夏装韩版印花T恤  纯棉修身t恤女士短袖',
    'num_iid' => '14535797213',
    'jifenbao' => '5.48',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1WIzXXbVnXXXmY5E4_053337.jpg',
  ),
  44 => 
  array (
    'item_title' => '斜挎包五层空间 新Kipling正品/basic 单肩斜挎包',
    'num_iid' => '16767592217',
    'jifenbao' => '5.95',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/87049461/T2FwyJXXVbXXXXXXXX_!!87049461.jpg',
  ),
  45 => 
  array (
    'item_title' => '新品上市 阿芙玫瑰精油(9.99%)8ml 单方正品 美白补水 淡斑',
    'num_iid' => '13796765953',
    'jifenbao' => '17.52',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T1HnbUXgBcXXbxlMA4_052759.jpg',
  ),
  46 => 
  array (
    'item_title' => '新款非主流品牌男装韩版男士休闲裤宽松锥形裤低档裤潮休闲哈伦裤',
    'num_iid' => '16681540060',
    'jifenbao' => '10.17',
    'commission_rate' => 13,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1o2xJXepBXXbirDM5_060230.jpg',
  ),
  47 => 
  array (
    'item_title' => '旁白孕妇裙 夏孕妇装 夏装 韩版时尚孕妇连衣裙新款孕妇夏装20001',
    'num_iid' => '14665970459',
    'jifenbao' => '8.23',
    'commission_rate' => 12,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1DK58XdRvXXciO8U3_050819.jpg',
  ),
  48 => 
  array (
    'item_title' => '明星嫩模anglebaby同款连衣裙巴黎时装周白色刺绣及地仙女长裙',
    'num_iid' => '15295903832',
    'jifenbao' => '5.70',
    'commission_rate' => 2,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1V.m.XaBeXXag8V7._111220.jpg',
  ),
  49 => 
  array (
    'item_title' => '暖浴快 松下浴霸FV-40BE1C PTC加热 无线遥控 含票 包邮 送配件',
    'num_iid' => '12924086310',
    'jifenbao' => '18.28',
    'commission_rate' => 1,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1H4e5Xb8mXXaVypDa_120030.jpg',
  ),
  50 => 
  array (
    'item_title' => '棕垫/软硬棕垫/椰棕床垫/棕榈床垫1.2 1.5 1.8米可定做折叠包邮',
    'num_iid' => '15285864595',
    'jifenbao' => '10.22',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T1Yae0XXNgXXbVdv3._111953.jpg',
  ),
  51 => 
  array (
    'item_title' => '欧利萨斯 透气正品拖鞋牛皮休闲凉鞋人字拖男士凉拖沙滩鞋男式鞋',
    'num_iid' => '10627518038',
    'jifenbao' => '6.13',
    'commission_rate' => 9,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1tJjKXg4bXXc9f9cW_024531.jpg',
  ),
  52 => 
  array (
    'item_title' => '正品化妆品 肌情蚕丝面膜 补水美白保湿隐形面膜贴 59包邮买1送10',
    'num_iid' => '8021688864',
    'jifenbao' => '6.86',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1gd6nXmXoXXcckGI._111301.jpg',
  ),
  53 => 
  array (
    'item_title' => '淘金币 2012夏新款 韩版 高品质水洗烫钻修身提臀薄款显瘦牛仔裤',
    'num_iid' => '15386371506',
    'jifenbao' => '5.36',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1VhzhXbxXXXcA63Db_123852.jpg',
  ),
  54 => 
  array (
    'item_title' => '淘金币 2012夏装 新款女装宽松无袖收腰假两件系带休闲背心裙连衣',
    'num_iid' => '15296515384',
    'jifenbao' => '7.09',
    'commission_rate' => 12,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T18IPpXnNbXXb7dOoW_024038.jpg',
  ),
  55 => 
  array (
    'item_title' => '淘金币 猎王日常休闲鞋潮流男鞋夏季透气韩版男鞋休闲男式鞋鞋子',
    'num_iid' => '6531127583',
    'jifenbao' => '9.88',
    'commission_rate' => 7,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T17wraXftoXXXQnO78_071137.jpg',
  ),
  56 => 
  array (
    'item_title' => '电脑椅 家用 特价 包邮 升降转椅子 办公椅 时尚 老板椅 弓形椅',
    'num_iid' => '15560547710',
    'jifenbao' => '7.95',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T1SESsXldYXXafbZ3Z_031633.jpg',
  ),
  57 => 
  array (
    'item_title' => '码上购澳罗拉 蓝莓软胶囊 缓解眼疲劳明目护眼 澳洲进口正品 越橘',
    'num_iid' => '10733192774',
    'jifenbao' => '9.21',
    'commission_rate' => 14,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1Qk5_Xc4oXXXd7KvX_115018.jpg',
  ),
  58 => 
  array (
    'item_title' => '秒杀！正品向阳良作去壳孔雀羽浮漂/枣核鲫鱼漂浮标套装 六选一',
    'num_iid' => '13163080213',
    'jifenbao' => '9.00',
    'commission_rate' => 5,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1FJyBXetWXXXtvD.._083607.jpg',
  ),
  59 => 
  array (
    'item_title' => '结婚贺喜 婚庆四件套龙凤百子图丝绸软缎被面床上用品红色 折扣！',
    'num_iid' => '4537453941',
    'jifenbao' => '32.20',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1jsLMXXBrXXXtka39_102445.jpg',
  ),
  60 => 
  array (
    'item_title' => '绿贝壳 抱被 新生儿用品 春夏 宝宝婴儿抱被 纯棉 包被 抱毯 包巾',
    'num_iid' => '12771280931',
    'jifenbao' => '5.74',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1kFYJXgtgXXb7gQs2_044704.jpg',
  ),
  61 => 
  array (
    'item_title' => '聚万人团HI-TEC海泰客男女款户外水陆两栖徒步溯溪鞋#20-5C095',
    'num_iid' => '14289513261',
    'jifenbao' => '11.06',
    'commission_rate' => 7,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1MmDeXn4cXXcoRWA__105335.jpg',
  ),
  62 => 
  array (
    'item_title' => '舒友阁祛黑头导出液套装中药去黑头鼻贴面膜粉刺收毛孔男女正品',
    'num_iid' => '12538770984',
    'jifenbao' => '6.73',
    'commission_rate' => 12,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1syrVXnpiXXbNJD7Y_030715.jpg',
  ),
  63 => 
  array (
    'item_title' => '花花公子家纺 床上用品 润肤被 加厚被芯 被子 秋冬被 清仓 包邮',
    'num_iid' => '13311563018',
    'jifenbao' => '5.99',
    'commission_rate' => 3,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1g8CoXhtzXXX9Y_Da_122417.jpg',
  ),
  64 => 
  array (
    'item_title' => '诺西 笔记本 散热器 电脑 散热底座 散热架 散热垫 板 14寸 包邮',
    'num_iid' => '9809879652',
    'jifenbao' => '5.18',
    'commission_rate' => 8,
    'name' => '******',
    'img' => 'http://img03.taobaocdn.com/bao/uploaded/i3/T1VDfxXftsXXXJgtE._111652.jpg',
  ),
  65 => 
  array (
    'item_title' => '送礼体面 飞利浦剃须刀PT730礼盒 双层刀片 全身水洗',
    'num_iid' => '14025340479',
    'jifenbao' => '7.82',
    'commission_rate' => 2,
    'name' => '******',
    'img' => 'http://img04.taobaocdn.com/bao/uploaded/i4/T1cc6QXeNiXXbf8iw5_055954.jpg',
  ),
  66 => 
  array (
    'item_title' => '道明亮光板式/嫣红色/亮光烤漆A03板式1.8米大床/双人床/包邮',
    'num_iid' => '13852562526',
    'jifenbao' => '10.95',
    'commission_rate' => 1,
    'name' => '******',
    'img' => 'http://img01.taobaocdn.com/bao/uploaded/i1/T1CguSXelhXXciUV2b_123018.jpg',
  ),
  67 => 
  array (
    'item_title' => '遥控直升机 遥控飞机 航模 大型直升机 陀螺仪 儿童玩具 70cm包邮',
    'num_iid' => '16473532212',
    'jifenbao' => '13.09',
    'commission_rate' => 6,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1VdvOXjxbXXcN8Njb_093943.jpg',
  ),
  68 => 
  array (
    'item_title' => '香草园强效瘦腿精油 瘦大腿瘦小腿按摩肌肉型减肥瘦身 送刮痧板',
    'num_iid' => '10778663564',
    'jifenbao' => '15.29',
    'commission_rate' => 20,
    'name' => '******',
    'img' => 'http://img02.taobaocdn.com/bao/uploaded/i2/T1ey9JXidwXXX0flA6_062600.jpg',
  ),
);
?>