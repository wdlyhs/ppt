<?php
return array(1=>'PC端banner',2=>'手机端banner');