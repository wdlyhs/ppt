$(document).ready(function(){$(window).scroll(function()
{var htmlTop=$(document).scrollTop();if(htmlTop>0){$("#header").addClass("mini");}
else{$("#header").removeClass("mini");}});});