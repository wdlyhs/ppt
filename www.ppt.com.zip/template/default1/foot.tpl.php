<div class="section7 hidden-xs">
<div class="container">
<div class="row">
<div class="col-md-3 col-sm-6">
<div class="s7-1 wow fadeInUp" data-wow-delay=".3s">
<h4><a title="联系我们" href="<?=list_url($duoduo,718)?>" target="_blank">联系我们</a></h4>
<p>Contact</p>
</div>
</div>
<div class="col-md-3 col-sm-6">
<div class="s7-2 wow fadeInUp" data-wow-delay=".3s">
<h4>微信客服</h4>
<div class="fenxiang">

<img src="<?=$webset['wx_img']?>"  style="max-width:50%">
</div>
</div>
</div>
<div class="col-md-3 col-sm-6">
<div class="s7-3 wow fadeInUp" data-wow-delay=".3s">
<h4><?=WEBNAME?></h4>
<p>
地 址：<?=$webset['address']?><br />
电 话：<?=$webset['tel']?><br />
微信：<?=$webset['weixin']?></p>
</div>
</div>
<div class="col-md-3 col-sm-6">
<div class="s7-4 wow fadeInUp" data-wow-delay=".3s">
<p>
邮政编码：<?=$webset['code']?><br />
手机：<?=$webset['mobile']?><br />
邮 箱：<?=$webset['email']?></p>
</div>
</div>
</div>
</div>
</div>
<div class="foot">


<div class="container wow fadeInUp" data-wow-delay=".3s">

<?=$webset['banquan']?>

</div>
</div>
<link rel="stylesheet" href="<?=SITEURL?>/<?=TPLURL?>/css/template-bottom.css" />
<script src="https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/<?=SITEURL?>/<?=TPLURL?>/js/jia.js" type="3347e483a4e9ba1bd3282e48-text/javascript"></script>

<script src="https://edge.yunjiasu.com/cdn-cgi/scripts/95c75768/cloudflare-static/rocket-loader.min.js" data-cf-settings="3347e483a4e9ba1bd3282e48-|49"></script>
<script src="<?=SITEURL?>/<?=TPLURL?>/js/stellar.js" type="3347e483a4e9ba1bd3282e48-text/javascript"></script>
<script type="3347e483a4e9ba1bd3282e48-text/javascript">$(function(){$.stellar({});});</script>
<div class="servers">
<!--[if (gte IE 7)|!(IE)]><!-->

<style type="text/css">
.izl-rmenu{position:fixed; left:0; margin-right:20px; bottom:0px; padding-bottom:0px;  z-index:999; }
.izl-rmenu .sbtn{width:72px; height:73px; margin-bottom:1px; cursor:pointer; position:relative;}



.izl-rmenu .btn-qq{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_qq.png) 0px 0px no-repeat; background-color:#6da9de;color:#FFF;}
.izl-rmenu .btn-qq:hover{background-color:#488bc7;color:#FFF;}
.izl-rmenu .btn-qq .qq{background-color:#488bc7; position:absolute; width:160px; right:-160px; top:0px; line-height:73px; color:#FFF; font-size:18px; text-align:center; display:none;}
.izl-rmenu .btn-qq a {color:#FFF;font-size:14px;}

.izl-rmenu .btn-wx{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_wx.png) 0px 0px no-repeat; background-color:#78c340;}
.izl-rmenu .btn-wx:hover{background-color:#58a81c;}
.izl-rmenu .btn-wx .pic{position:absolute; right:-160px; top:0px; display:none;width:140px;height:140px;}

.izl-rmenu .btn-phone{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_phone.png) 0px 0px no-repeat; background-color:#fbb01f;}
.izl-rmenu .btn-phone:hover{background-color:#ff811b;}
.izl-rmenu .btn-phone .phone{background-color:#ff811b; position:absolute; width:160px; right:-160px; top:0px; line-height:73px; color:#FFF; font-size:18px; text-align:center; display:none;}

.izl-rmenu .btn-ali{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_ali.png) 0px 0px no-repeat; background-color:#B8860B;}
.izl-rmenu .btn-ali:hover{background-color:#808000;}
.izl-rmenu a.btn-ali,.izl-rmenu a.btn-ali:visited{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_ali.png) 0px 0px no-repeat; background-color:#B8860B; text-decoration:none; display:block;}


.izl-rmenu .btn-wangwang{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_wangwang.png) 0px 0px no-repeat; background-color:#FFD700;}
.izl-rmenu .btn-wangwang:hover{background-color:#DAA520;}
.izl-rmenu a.btn-wangwang,.izl-rmenu a.btn-wangwang:visited{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_wangwang.png) 0px 0px no-repeat; background-color:#FFD700; text-decoration:none; display:block;}


.izl-rmenu .btn-skype{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_skype.png) 0px 0px no-repeat; background-color:#FF69B4;}
.izl-rmenu .btn-skype:hover{background-color:#8B008B;}
.izl-rmenu a.btn-skype,.izl-rmenu a.btn-skype:visited{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_skype.png) 0px 0px no-repeat; background-color:#FF69B4; text-decoration:none; display:block;}

.izl-rmenu .btn-web{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_web.png) 0px 0px no-repeat; background-color:#008a46;}
.izl-rmenu .btn-web:hover{background-color:#00663a;}
.izl-rmenu a.btn-web,.izl-rmenu a.btn-web:visited{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_web.png) 0px 0px no-repeat; background-color:#008a46; text-decoration:none; display:block;}


.izl-rmenu .btn-top{background:url(https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/servers/metro_color/r_top.png) 0px 0px no-repeat; background-color:#666666; display:none;}
.izl-rmenu .btn-top:hover{background-color:#444;}
</style>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script language="javascript" type="3347e483a4e9ba1bd3282e48-text/javascript">
$(function(){
var tophtml="<div id=\"izl_rmenu\" class=\"izl-rmenu\"><div class=\"sbtn btn-qq\"><div class=\"qq\"><a rel=\"nofollow\" target=\"_blank\" href=\"tencent://Message/?Uin=1721768801&websiteName=./=&Menu=yes\">客服一</a><br /><a rel=\"nofollow\" target=\"_blank\" href=\"tencent://Message/?Uin=1721768801&websiteName=./=&Menu=yes\">客服二</a></div></div><a rel=\"nofollow\" href=\"http://amos.im.alisoft.com/msg.aw?v=2&uid=cmseasy&site=cntaobao&s=1&charset=utf-8\" target=\"_blank\" class=\"sbtn btn-wangwang\"></a><a rel=\"nofollow\" target=\"_blank\" href=\"http://web.im.alisoft.com/msg.aw?v=2&uid=cmseasy&site=cnalichn&s=10\" class=\"sbtn btn-ali\"></a><a rel=\"nofollow\" target=\"_blank\" href=\"skype:admin@admin.com?call\" target=\"_blank\" class=\"sbtn btn-skype\"></a><div class=\"sbtn btn-wx\"><img class=\"pic\" src=\"/images/w.gif\" onclick=\"window.location.href=\'http:\'\"/></div><div class=\"sbtn btn-phone\"><div class=\"phone\">400-400-4000</div></div><div class=\"sbtn btn-top\"></div></div>";
$("#top").html(tophtml);
$("#izl_rmenu").each(function(){
$(this).find(".btn-qq").mouseenter(function(){
$(this).find(".qq").fadeIn("fast");
});
$(this).find(".btn-qq").mouseleave(function(){
$(this).find(".qq").fadeOut("fast");
});
$(this).find(".btn-wx").mouseenter(function(){
$(this).find(".pic").fadeIn("fast");
});
$(this).find(".btn-wx").mouseleave(function(){
$(this).find(".pic").fadeOut("fast");
});
$(this).find(".btn-phone").mouseenter(function(){
$(this).find(".phone").fadeIn("fast");
});
$(this).find(".btn-phone").mouseleave(function(){
$(this).find(".phone").fadeOut("fast");
});
$(this).find(".btn-top").click(function(){
$("html, body").animate({
"scroll-top":0
},"fast");
});
});
var lastRmenuStatus=false;
$(window).scroll(function(){//bug
var _top=$(window).scrollTop();
if(_top>200){
$("#izl_rmenu").data("expanded",true);
}else{
$("#izl_rmenu").data("expanded",false);
}
if($("#izl_rmenu").data("expanded")!=lastRmenuStatus){
lastRmenuStatus=$("#izl_rmenu").data("expanded");
if(lastRmenuStatus){
$("#izl_rmenu .btn-top").slideDown();
}else{
$("#izl_rmenu .btn-top").slideUp();
}
}
});
});
</script>
<div id="top"></div><![endif]-->

</div>
<div class="servers-wap">
<style type="text/css">



#plug-wrap {
    position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background: rgba(0, 0, 0, 0);
    z-index:800;
}
.top_bar {
    position:fixed;
    bottom:0;
    right:0px;
    z-index:900;
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    font-family: Helvetica, Tahoma, Arial, Microsoft YaHei, sans-serif;
}
.plug-menu {
    -webkit-appearance:button;
    display:inline-block;
    width:36px;
    height:36px;
    border-radius:36px;
    position: absolute;
    bottom:17px;
    right: 17px;
    z-index:999;
    box-shadow: 0 0 0 4px #FFFFFF, 0 2px 5px 4px rgba(0, 0, 0, 0.25);
   
    -webkit-transition: -webkit-transform 200ms;
    -webkit-transform:rotate(1deg);
    color:#fff;
    background-image:url('https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/wao/plug.png');
    background-repeat: no-repeat;
    -webkit-background-size: 80% auto;
    background-size: 80% auto;
    background-position: center center;
}
.plug-menu:before {
    font-size:20px;
    margin:9px 0 0 9px;
}
.plug-menu:checked {
    -webkit-transform:rotate(135deg);
}
.top_menu>li {
    width: 32px;
    height:32px;
    border-radius:32px;
    box-shadow: 0 0 0 3px #FFFFFF, 0 2px 5px 3px rgba(0, 0, 0, 0.25);
    
    position:absolute;
    bottom:0;
    right:0;
    margin-bottom: 20px;
    margin-right:20px;
    z-index:900;
    -webkit-transition: -webkit-transform 200ms;
}
.top_menu>li a {
    color:#fff;
    font-size:20px;
    display: block;
    height: 100%;
    line-height: 33px;
    text-align: center;
}
.top_menu>li>a label{
display:none;
}
.top_menu>li a img {
display: block;
width: 22px;
height: 22px;
text-indent: -999px;
position: absolute;
top: 50%;
left: 50%;
margin-top: -11px;
margin-left: -11px;
}
.top_menu>li.on:nth-of-type(1) {
-webkit-transform: translate(-0, -100px) rotate(720deg);
}
.top_menu>li.on:nth-of-type(2) {
-webkit-transform: translate(-47px, -81px) rotate(720deg);
}
.top_menu>li.on:nth-of-type(3) {
-webkit-transform: translate(-81px, -45px) rotate(720deg);
}
.top_menu>li.on:nth-of-type(4) {
-webkit-transform: translate(-100px, 0) rotate(720deg);
}
 
#sharemcover {
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background: rgba(0, 0, 0, 0.7);
display: none;
z-index: 20000;
}
#sharemcover img {
position: fixed;
right: 18px;
top: 5px;
width: 260px;
height: 180px;
z-index: 20001;
border:0;
}

</style>
<div class="top_bar" style="-webkit-transform:translate3d(0,0,0)">
<nav>
<ul id="top_menu" class="top_menu">
<input type="checkbox" id="plug-btn" class="plug-menu themeStyle" style="background-image:url('https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/wap/plug.png');border:0px;">
<li class="themeStyle out" style="background:">
<a href="tel:400-400-4000"><img src="https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/wap/plugmenu1.png"><label>电 话</label></a>
</li>
<li class="themeStyle out" style="background:">
<a href="sms:18888888888"><img src="https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/wap/plugmenu3.png"><label>短信</label></a>
</li>
<li class="themeStyle out" style="background:">
<a href="https://wpa.qq.com/msgrd?v=3&uin=1721768801&site=qq&menu=yes" id="btn_fenxiang"><img src="https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/wap/plugmenu5.png"><label>QQ号码</label></a>
</li>
<li class="themeStyle out" style="background:">
<a href="https://www.cmseasy.cn/demo/business-template/v471/index.php?case=guestbook&act=index"><img src="https://www.cmseasy.cn/demo/business-template/v471/template/CmsEasy_V_471/skin/images/wap/plugmenu6.png"><label>留言</label></a>
</li>
</ul>
</nav>
</div>
<div id="plug-wrap" style="display: none;"></div>
<script type="3347e483a4e9ba1bd3282e48-text/javascript">
$(function(){
        $(".plug-menu").click(function(){
        var li = $(this).parents('ul').find('li');
        if(li.attr("class") == "themeStyle on"){
                li.removeClass("themeStyle on");
                li.addClass("themeStyle out");
        }else{
                li.removeClass("themeStyle out");
                li.addClass("themeStyle on");
        }
        });
});
</script>
</div>
<script type="3347e483a4e9ba1bd3282e48-text/javascript" src="https://www.cmseasy.cn/demo/business-template/v471/js/common.js"></script>
<script type="3347e483a4e9ba1bd3282e48-text/javascript">
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<script type="3347e483a4e9ba1bd3282e48-text/javascript">window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"slide":{"type":"slide","bdImg":"6","bdPos":"right","bdTop":"100"},"image":{"viewList":["qzone","tsina","tqq","renren","weixin"],"viewText":"分享到：","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
<script type="3347e483a4e9ba1bd3282e48-text/javascript">
<!--
$(document).ready(function(){
$(window).scroll(function() {
var top = $(".slide-text h1,.sub_menu").offset().top; //获取指定位置
var scrollTop = $(window).scrollTop();  //获取当前滑动位置
if(scrollTop > top){                 //滑动到该位置时执行代码
$(".navbar").addClass("active");
}else{
$(".navbar").removeClass("active");
}
});
});
//-->
</script>




<script src="<?=SITEURL?>/<?=TPLURL?>/js/holder.min.js" type="3347e483a4e9ba1bd3282e48-text/javascript"></script>

<script src="<?=SITEURL?>/<?=TPLURL?>/js/ie10-viewport-bug-workaround.js" type="3347e483a4e9ba1bd3282e48-text/javascript"></script>
<script src="<?=SITEURL?>/<?=TPLURL?>/js/bootstrap-submenu.js" type="3347e483a4e9ba1bd3282e48-text/javascript"></script>
<script src="<?=SITEURL?>/<?=TPLURL?>/js/docs.js" type="3347e483a4e9ba1bd3282e48-text/javascript"></script>
<!--[if lt IE 9]><!-->
<script src="<?=SITEURL?>/<?=TPLURL?>/js/ie/html5shiv.min.js" type="3347e483a4e9ba1bd3282e48-text/javascript"></script>
<script src="<?=SITEURL?>/<?=TPLURL?>/js/ie/respond.min.js" type="3347e483a4e9ba1bd3282e48-text/javascript"></script>
<![endif]-->
<script type="3347e483a4e9ba1bd3282e48-text/javascript">
<!--
$(function () {
    $(".dropdown").mouseover(function () {
        $(this).addClass("open");
    });

    $(".dropdown").mouseleave(function(){
        $(this).removeClass("open");
    })

})


</script>
<script type="3347e483a4e9ba1bd3282e48-text/javascript">
$('#bootstrap-touch-slider').bsTouchSlider();
</script>
<script src="https://edge.yunjiasu.com/cdn-cgi/scripts/95c75768/cloudflare-static/rocket-loader.min.js" data-cf-settings="3347e483a4e9ba1bd3282e48-|49" defer="">


</body>
</html>