<div class='p-banner'>
    <div class='img-header'><img  data-original="<?=head_img($dduser['id'])?>" class="lazy" width="83"></div>
    <div class='u-name'>

        <div style="float:left;">
          账号：<?=$dduser['name']?>(ID:<?=$dduser['id']?>)

            
        </div>

       
        <!--<div class='userlabel' style="width:200px;">  
                    <span class="bangphone"><i></i>手机绑定</span>
        </div>-->  
        <div class='userlabel' style="width:270px; text-align:left">欢迎来到会员中心
        </div>
    </div>
    </div>