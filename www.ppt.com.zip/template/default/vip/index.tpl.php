<?
include(TPLURL."/head.tpl.php");
?>

<link rel="stylesheet" type="text/css" href="<?=TPLURL?>/css/intro20190917.css">




 <!--中部的东西-->
<div class='banner' style="background: url(<?=$webset['ad1']['vip']?>) center center no-repeat;">
    <a target="_blank" href="javascript:;" class='opne openvip jianvip'>开通会员</a>
</div>

<!--<div class='jsao'>
    <ul>
      <li>
          <span class='tse'>功能特权</span>
          <span class='line'></span>
          <span class='ptt'>下载权限</span>
          <span class='ptt'>全站下载</span>
          <span class='ptt'>每日更新</span>
          <span class='ptt'>海量收藏权限</span>
          <span class='ptt'>高速下载</span>
          <span class='ptt'>优先客服接待</span>
          <span class='ptt'>身份铭牌</span>
      </li>
      <li class='jsao-more more-two'>
        <div class='top'>【超值】即将恢复原价</div>
        <span class='taoc'>终身VIP</span>
        <span class='qian'><em>￥</em>199<b>原价299</b></span>
        <a href="/purchase?type=1&from=top" target="_blank">开通会员</a>
        <span class='pt jc'>任意下载</span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
         <span class='gou'><i></i></span>
      </li>
       <li class='jsao-more '>
        <div class='top  top2'>【活动】买1年送1年</div>
        <span class='taoc'>包年VIP</span>
        <span class='qian'><em>￥</em>99</span>
        <a target="_blank" href="/purchase?type=2&from=top">开通会员</a>
        <span class='pt jc'>任意下载</span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
       <span class='gou'><i></i></span>
      </li>
       <li class='jsao-more'>
        <span class='taoc'>包年VIP</span>
        <span class='qian'><em>￥</em>49</span>
        <a  target="_blank" href="/purchase?type=3&from=top">开通会员</a>
        <span class='pt jc'>10个/天</span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
      </li>
       <li class='jsao-more'>
        <span class='taoc'>包日VIP</span>
        <span class='qian'><em>￥</em>19</span>
        <a target="_blank" href="/purchase?type=4&from=top">开通会员</a>
        <span class='pt jc'>2个/天</span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
        <span class='gou'><i></i></span>
       
        <span class='xia'><i></i></span>
        <span class='xia'><i></i></span>
        <span class='xia'><i></i></span>
      </li>
       <li class='jsao-more'>
       <span class='taoc'>普通用户</span>
        <span class='qian'><em>￥</em>0</span>
        <a class='heibai'>注册即可</a>
        <span class='pt jc'>2个/天 <em>（限分类）</em>
        <div  class='notice'>
          <div class='not' >
            <div class='noone'>可下载分类</div>   
            <div class='notwo'>
                            PPT图表/广告设计/免抠元素/摄影图
                          </div>   
          </div>
        </div></span>
        <span class='xia'><i></i></span>
        <span class='xia'><i></i></span>
        <span class='xia'><i></i></span>
        <span class='xia'><i></i></span>
       <span class='xia'><i></i></span>
       <span class='xia'><i></i></span>
      </li>
    </ul>
    
    <div class='qqkefu'>对套餐使用情况如有疑问，欢迎您随时咨询
      <a href="http://q.url.cn/cdUM4o?_type=wpa&amp;qidian=true" target="_blank" >在线客服</a>
    </div>
</div>-->
<div class='special-vip'>
  <div class='title'>VIP特权服务</div>
  <ul>
    <li>
      <i class='ione'></i>
      <span>每日更新</span>
    </li>
    <li>
      <i class='itwo'></i>
      <span>权益保障</span>
    </li>
    <li>
      <i class='ithree'></i>
      <span>贴心客服</span>
    </li>
    <li>
      <i class='ifour'></i>
      <span>精品模板</span>
    </li>
    <li>
      <i class='ifive'></i>
      <span>高速下载</span>
    </li>
  </ul>
  <a  class="openvip jianvip" target="_blank" href="javascript:;">开通会员</a>
</div>






<?
include(TPLURL."/foot.tpl.php");
?>