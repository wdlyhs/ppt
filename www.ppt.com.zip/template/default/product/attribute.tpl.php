<?
	$cid=$_REQUEST['cid'];
	$pid=$_REQUEST['pid'];
	$tmep_cid=get_title("product",$pid,"cid");
	$rows=$duoduo->select_all("attribute","*","cid=$cid order by sort desc,id desc"); 
	$html="";
	foreach ($rows as $row){
?> 
    <?  if ($row['input_type']==1){ ?>
        <tr class="arr">
        <td width="115px" align="right"><?=$row['title']?>：</td>
        <td>&nbsp;<input name="product_<?=$row['id']?>" type="text" value="<?=a1($cid,$pid,$row['id'])?>" /></td>
         </tr>
    <? }?>
    
    <?  if ($row['input_type']==2){
		   $arrs=attribute_arr($row['id']);
		   $b=a1($cid,$pid,$row['id']);
		  
		 ?>
        <tr class="arr">
        <td width="115px" align="right"><?=$row['title']?>：</td>
        <td>&nbsp;<?=select($arrs,$b,"product_".$row['id'])?></td>
         </tr>
    <? }?>
    
     <?  if ($row['input_type']==3){
		   $arrs=attribute_arr($row['id']);
		   $b=a2($cid,$pid,$row['id']);
		   
		 ?>
        <tr class="arr">
        <td width="115px" align="right"><?=$row['title']?>：</td>
        <td><?=checkbox($arrs,$b,"product_".$row['id'])?></td>
         </tr>
    <? }?>
    
    
    
    
<? }?>

