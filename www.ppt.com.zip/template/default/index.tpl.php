<?
jump(u("product","list"));
?>