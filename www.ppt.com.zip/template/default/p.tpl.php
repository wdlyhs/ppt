 <div class="crumbs wlimit">
    
      <?=dd_position($duoduo,$_GET['cid'])?><?=(ACT=="view")?">".$article['title']:""?>
      
  
     
     </div>