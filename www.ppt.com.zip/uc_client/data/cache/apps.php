<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZX',
    'name' => 'Discuz! Board',
    'url' => 'http://localhost/dz/dz20utf',
    'ip' => '127.0.0.1',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => '',
    'recvnote' => '1',
  ),
  2 => 
  array (
    'appid' => '2',
    'type' => 'OTHER',
    'name' => 'dd20110602',
    'url' => 'http://localhost/duoduo/dd20110602',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '0',
  ),
);
