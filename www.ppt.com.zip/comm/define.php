<?php //常量定义
define('WEB_USER_LEVEL',4);
define('TAO_FREEZE_DAY',16);
define('DEFAULTPWD','123duoduo321');
define('CHANET_GET_KEY_URL','http://www.chanet.com.cn/api/pt/duoduo_bind.cgi');
define('DUODUO_URL','http://demo.duoduo123.com');
define('TAOLOGO','http://logo.taobaocdn.com/shop-logo');
define('PHP_EXIT','<?php exit;?>');
define('PHP_EXIT_PREG','<\?php exit;\?>');
define('DOMAIN_PREG',"/[\x80-\xff\w-]+\.(com|net|org|gov|la|cc|biz|info|cn|tk|mobi|co|so|tel|tv|yt|name|asia|me|pk|in|ru|vc|sc|cd|gd|cm|hk|li|om|us|vn|pro|bi|pw|ws|ma|im|tw|de|wang|ren|xyz|top|online|gg|xin|ee|co\.jp|中国|公司|网络)((\.cn|\.hk|))$/");
define('DD_OPEN_URL','http://issue.duoduo123.com');
define('DD_YUN_URL','http://yun.duoduo123.com');
define('DD_U_URL','http://u.duoduo123.com');
define('DD_AUTH_URL','http://auth.duoduo123.com');
define('DD_FANLICHENG_URL','http://www.fanlicheng.com');
define('DD_OPEN_JFB_HELP_URL',DD_AUTH_URL.'/jfb.php');
define('DD_OPEN_SMS_HELP_URL',DD_AUTH_URL.'/sms.php');
define('DD_OPEN_JFB_REG_URL',DD_OPEN_URL.'/index.php?m=user&a=reg&url=');
define('CHARSET','UTF-8');
define('TAO_REPORT_GET_NUM',100);
define('PLUGIN_2',20130612);
define('JFB_TX_MAX',50000);
define('BUY_LOG_DAY',30);
define('GUANLIAN_NUM',2);
define('TAO_API_GET_NUM',10);
define('DEFAULT_SORT',0);
define('MAX_ERROR_LOGIN_NUM',3);
define('DLADMIN',0);
?>