<?php //多多
$_GET['p']='getchanet';
include('../page/page.php');
?>