<?php //多多
$_GET['p']='get59miao';
include('../page/page.php');
?>