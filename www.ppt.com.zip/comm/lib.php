<?php //调用
include_once (DDROOT . '/comm/define.php');
include_once (DDROOT . '/comm/dd.class.php');
include_once (DDROOT . '/comm/json.php');
include_once (DDROOT . '/comm/collect.class.php');
include_once (DDROOT . '/comm/comm.func.php');
include_once (DDROOT . '/comm/mod.func.php');
include_once (DDROOT . '/comm/dd.func.php');
include_once (DDROOT . '/comm/page.class.php');
include_once (DDROOT.'/comm/php_lock.class.php');
?>