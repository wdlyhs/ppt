<?php
$_GET['p']='getlinktech';
include('../page/page.php');
?>