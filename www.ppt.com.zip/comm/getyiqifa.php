<?php
$_GET['p']='getyiqifa';
include('../page/page.php');
?>