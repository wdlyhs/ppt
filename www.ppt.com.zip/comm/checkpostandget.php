<?php
StopAttack();
?>