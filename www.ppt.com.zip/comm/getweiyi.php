<?php
$_GET['p']='getweiyi';
include('../page/page.php');
?>