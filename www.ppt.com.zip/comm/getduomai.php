<?php
$_GET['p']='getduomai';
include('../page/page.php');
?>