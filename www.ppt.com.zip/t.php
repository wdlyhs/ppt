<?
$str='a:4:{s:9:"signature";s:40:"916d9e82f7d990899c952d50f52cd10e74d782f1";s:7:"echostr";s:19:"3152124067406920828";s:9:"timestamp";s:10:"1572845688";s:5:"nonce";s:10:"1932394034";}';
$row=unserialize($str);
echo http_build_query( $row);
?>